const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const toast = $('#toast');
let toastTimer;

function showToast(message) {
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2600);
}

const composer = $('#composer');
const postText = $('#postText');
$('#jumpToComposer').addEventListener('click', () => {
  composer.classList.add('expanded');
  postText.focus();
  composer.scrollIntoView({ behavior: 'smooth', block: 'center' });
});
$('#focusPost').addEventListener('click', () => {
  composer.classList.add('expanded');
  postText.focus();
});

$('#publishPost').addEventListener('click', () => {
  const text = postText.value.trim();
  if (!text) {
    composer.classList.add('expanded');
    $('#composerHint').textContent = 'Write something before publishing.';
    postText.focus();
    return;
  }
  const article = document.createElement('article');
  article.className = 'post card';
  article.dataset.search = text.toLowerCase();
  const header = document.createElement('div');
  header.className = 'post-header';
  header.innerHTML = '<div class="avatar avatar-me">J</div><div class="post-author"><strong>Jackson <span class="verified">✓</span></strong><small>Just now · Demo post</small></div><button class="dots-button" aria-label="More post options">···</button>';
  const paragraph = document.createElement('p');
  paragraph.className = 'post-copy';
  paragraph.textContent = text;
  const stats = document.createElement('div');
  stats.className = 'post-stats';
  stats.innerHTML = '<span class="likes-count">♡ 0 likes</span><span>0 comments · 0 shares</span>';
  const actions = document.createElement('div');
  actions.className = 'post-actions';
  actions.innerHTML = '<button class="like-button">♡ <span>Like</span></button><button class="comment-button">▱ <span>Comment</span></button><button class="share-button">↗ <span>Share</span></button>';
  const comments = document.createElement('div');
  comments.className = 'comment-area';
  comments.innerHTML = '<input type="text" placeholder="Write a thoughtful comment..." aria-label="Write a comment"><button class="send-comment">Send</button>';
  article.append(header, paragraph, stats, actions, comments);
  $('#feedPosts').prepend(article);
  postText.value = '';
  $('#composerHint').textContent = 'Your demo post has been added to this page.';
  composer.classList.remove('expanded');
  attachPostHandlers(article);
  showToast('Post published in this demo!');
});

function attachPostHandlers(root = document) {
  $$('.like-button', root).forEach(button => {
    if (button.dataset.ready) return;
    button.dataset.ready = '1';
    button.addEventListener('click', () => {
      button.classList.toggle('liked');
      const liked = button.classList.contains('liked');
      button.innerHTML = liked ? '♥ <span>Liked</span>' : '♡ <span>Like</span>';
      const post = button.closest('.post');
      const count = post.querySelector('.likes-count');
      const current = Number((count.textContent.match(/\d+/) || ['0'])[0]);
      count.textContent = `${liked ? '♥' : '♡'} ${Math.max(0, current + (liked ? 1 : -1))} likes`;
    });
  });
  $$('.comment-button', root).forEach(button => {
    if (button.dataset.ready) return;
    button.dataset.ready = '1';
    button.addEventListener('click', () => {
      const area = button.closest('.post').querySelector('.comment-area');
      area.classList.toggle('visible');
      if (area.classList.contains('visible')) area.querySelector('input').focus();
    });
  });
  $$('.send-comment', root).forEach(button => {
    if (button.dataset.ready) return;
    button.dataset.ready = '1';
    button.addEventListener('click', () => {
      const area = button.closest('.comment-area');
      const input = area.querySelector('input');
      if (!input.value.trim()) { input.focus(); return; }
      const post = button.closest('.post');
      const stats = post.querySelector('.post-stats span:last-child');
      const commentCount = Number((stats.textContent.match(/\d+ comments/) || ['0 comments'])[0].match(/\d+/)[0]);
      stats.textContent = `${commentCount + 1} comments · demo`;
      showToast('Comment added in this demo.');
      input.value = '';
      area.classList.remove('visible');
    });
  });
  $$('.share-button', root).forEach(button => {
    if (button.dataset.ready) return;
    button.dataset.ready = '1';
    button.addEventListener('click', async () => {
      const text = button.closest('.post').querySelector('.post-copy')?.textContent || 'Check out NEXORA';
      try {
        if (navigator.share) await navigator.share({ title: 'NEXORA', text });
        else if (navigator.clipboard) { await navigator.clipboard.writeText(text); showToast('Post text copied to clipboard.'); }
        else showToast('Sharing is a demo feature in this version.');
      } catch (error) {
        if (error.name !== 'AbortError') showToast('Sharing is not available here.');
      }
    });
  });
}
attachPostHandlers();

$('#searchInput').addEventListener('input', event => {
  const query = event.target.value.trim().toLowerCase();
  let visible = 0;
  $$('.post', $('#feedPosts')).forEach(post => {
    const match = !query || (post.dataset.search || post.textContent).toLowerCase().includes(query);
    post.hidden = !match;
    if (match) visible++;
  });
  $('#emptyState').hidden = visible !== 0;
});

$('#sortButton').addEventListener('click', () => {
  const feed = $('#feedPosts');
  const posts = $$('.post', feed);
  posts.reverse().forEach(post => feed.insertBefore(post, $('#emptyState')));
  $('#sortButton').textContent = $('#sortButton').textContent.includes('Latest') ? 'Oldest⌄' : 'Latest⌄';
  showToast('Feed order changed.');
});

$$('.follow-button').forEach(button => {
  button.addEventListener('click', () => {
    const following = button.classList.toggle('following');
    button.textContent = following ? 'Following' : 'Follow';
    showToast(following ? 'Following in this demo.' : 'Unfollowed in this demo.');
  });
});

$('#menuToggle').addEventListener('click', () => $('#sidebar').classList.toggle('open'));
$$('.nav-link').forEach(link => {
  link.addEventListener('click', () => {
    $$('.nav-link').forEach(item => item.classList.remove('active'));
    link.classList.add('active');
    const label = link.textContent.trim().replace(/\s+\d+$/, '');
    $('#pageTitle').textContent = label;
    if (window.innerWidth <= 700) $('#sidebar').classList.remove('open');
    const target = link.dataset.view;
    if (target === 'videos') showToast('Video discovery is a UI demo in this version.');
    if (target === 'messages') showToast('Messaging requires a backend to work.');
    if (target === 'saved') showToast('Saved posts can be connected to a database later.');
    if (target === 'explore') $('#explore').scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
});

$('#addStory').addEventListener('click', () => showToast('Story uploads can be added with a backend and media storage.'));
$('#photoTool').addEventListener('click', () => showToast('Photo uploads are a planned feature for the backend version.'));
$('#videoTool').addEventListener('click', () => showToast('Video uploads are a planned feature for the backend version.'));
$('#moodTool').addEventListener('click', () => {
  const moods = ['feeling inspired ✨', 'feeling creative 🎨', 'feeling grateful 💜'];
  const mood = moods[Math.floor(Math.random() * moods.length)];
  composer.classList.add('expanded');
  postText.value = `${postText.value.trim()} ${mood}`.trim();
  postText.focus();
});
$('#editProfile').addEventListener('click', () => showToast('Profile editing will be available when account features are connected.'));
